#include <iostream>
using namespace std;

int main()
{
    int *ptr = NULL;

    *ptr = 42;
}
