// simple program to demonstrate how to use make

#include <iostream>

using namespace std;

int
main()
{
    cout << "hello world" << endl;

    return 0; // everything ok
}
