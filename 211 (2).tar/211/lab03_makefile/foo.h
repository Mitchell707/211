// Simple class that stores a pair of numbers

#ifndef FOO_H
#define FOO_H

class Foo
{
    public:
        Foo(int x, int y);
        void print();
    private:
        int m_x;
        int m_y;
};

#endif
