#include <iostream>
using namespace std;


int main(int argc, char *argv[])
{
    cout << "replace this with code with code that adds are the arguments\n";
}
